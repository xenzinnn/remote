# IR Home Remote (Android starter project)

A small native Android app UI for an IR-blaster phone, with:
- Light power switch
- Warm-to-cool color-temperature slider (three preset commands)
- Brightness slider (11 discrete positions: 0–100% in 10% steps)
- Fan power switch
- Three fan-speed levels

## Important: device IR codes are required

This project is a working UI and IR-transmission scaffold, but it will **not control your actual appliances until their IR pulse patterns are added**. IR codes differ by brand/model. `IrCommands.kt` intentionally contains empty arrays rather than invented codes.

The app uses Android's `ConsumerIrManager` API and sends raw pulse durations in microseconds. You need the exact patterns for:
- Light on/off
- Warm / neutral / cool (or the available presets)
- Brightness levels, if the lamp supports them
- Fan on/off and levels 1–3

Some remotes use toggle commands or brightness up/down commands instead of direct levels. In that case, the command mapping should be adapted to the remote's protocol.

## Build in Android Studio

1. Open the `IRHomeRemote` folder in Android Studio.
2. Let Gradle sync.
3. Connect an Android phone that has an IR blaster and run the app.
4. Confirm the app reports that an IR emitter is detected.
5. Add the real pulse patterns in `app/src/main/java/com/example/irhomeremote/IrCommands.kt`, then rebuild.

No runtime permission prompt is normally required for `TRANSMIT_IR`, but the phone must physically include an IR emitter and expose it through Android.

## Next step to make it actually work

Send the **brand and model** of the light and fan, or photos of their original remotes (front and any model label). I can help map the controls and adapt the app to the actual commands. A photo alone may not reveal raw pulse timings; some remotes require a compatible learning tool or known protocol data.
